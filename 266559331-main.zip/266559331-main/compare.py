match name:
    case "Herry":
        print("d")
    case "pootr":
        print("ds")
